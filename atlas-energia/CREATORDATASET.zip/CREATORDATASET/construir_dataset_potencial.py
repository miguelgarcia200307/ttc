# -*- coding: utf-8 -*-
"""
Dataset Potencial Renovable - Constructor de Dataset Completo
=============================================================

Este script toma como entrada el archivo DIVIPOLA_municipios.csv y lo enriquece
consumiendo multiples APIs oficiales para construir un dataset completo de 
potencial de energias renovables por municipio en Colombia.

Fuentes de datos:
- NASA POWER: Climatologia (radiacion solar, viento, temperatura, humedad, nubosidad)  
- Open-Elevation: Altitud sobre el nivel del mar (SRTM)
- Datos.gov.co ZNI: Clasificacion de red electrica (SIN/ZNI)

Author: Generated for renewable energy potential analysis
Date: November 2025
"""

import os
import time
import requests
import pandas as pd
from typing import List, Dict, Any, Tuple


# =============================================================================
# CONFIGURACION
# =============================================================================

# Archivos de entrada y salida
DIVIPOLA_CSV = "DIVIPOLA_municipios.csv"
OUTPUT_CSV = "dataset_potencial_renovable.csv"
ALTITUDE_CACHE_CSV = "altitudes_cache.csv"

# URLs de APIs
POWER_BASE_URL = "https://power.larc.nasa.gov/api/temporal/climatology/point"
OPEN_ELEVATION_URL = "https://api.open-elevation.com/api/v1/lookup"
ZNI_URL = "https://www.datos.gov.co/resource/3ebi-d83g.json"

# Parametros de NASA POWER
POWER_PARAMS = [
    "ALLSKY_SFC_SW_DWN",    # Irradiacion solar global
    "WS10M",                # Velocidad del viento a 10m
    "T2M",                  # Temperatura a 2m
    "RH2M",                 # Humedad relativa a 2m
    "CLRSKY_SFC_SW_DWN",   # Irradiacion cielo despejado
]

# Token opcional para datos.gov.co
APP_TOKEN_ZNI = os.getenv("DATOS_GOV_APP_TOKEN", None)

# Precision de coordenadas para cache (4 decimales = 11m)
COORD_PRECISION = 4


# =============================================================================
# FUNCIONES PRINCIPALES
# =============================================================================

def load_divipola(path: str = DIVIPOLA_CSV) -> pd.DataFrame:
    """
    Carga el archivo DIVIPOLA_municipios.csv y valida su estructura.
    
    Args:
        path (str): Ruta al archivo CSV de DIVIPOLA
    
    Returns:
        pd.DataFrame: DataFrame con datos de municipios validados
    
    Raises:
        FileNotFoundError: Si el archivo no existe
        ValueError: Si faltan columnas requeridas
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"Archivo DIVIPOLA no encontrado: {path}")
    
    print(f"📊 Cargando datos DIVIPOLA desde {path}...")
    
    # Cargar CSV
    df = pd.read_csv(path, encoding='utf-8')
    
    # Verificar columnas requeridas
    required_columns = ['departamento', 'municipio', 'codigo_dane_municipio', 'latitud', 'longitud']
    missing_columns = [col for col in required_columns if col not in df.columns]
    
    if missing_columns:
        raise ValueError(f"Faltan columnas requeridas: {missing_columns}")
    
    # Limpiar y validar tipos de datos
    df['departamento'] = df['departamento'].astype(str).str.upper().str.strip()
    df['municipio'] = df['municipio'].astype(str).str.upper().str.strip()
    df['codigo_dane_municipio'] = df['codigo_dane_municipio'].astype(str).str.strip()
    df['latitud'] = pd.to_numeric(df['latitud'], errors='coerce')
    df['longitud'] = pd.to_numeric(df['longitud'], errors='coerce')
    
    # Eliminar registros con coordenadas invalidas
    initial_count = len(df)
    df = df.dropna(subset=['latitud', 'longitud'])
    final_count = len(df)
    
    if initial_count != final_count:
        print(f"⚠️  Eliminados {initial_count - final_count} registros con coordenadas invalidas")
    
    print(f"✅ Cargados {len(df)} municipios de {df['departamento'].nunique()} departamentos")
    return df


def load_altitude_cache(path: str = "altitudes_cache.csv") -> Dict[Tuple[float, float], float]:
    """
    Carga cache de altitudes desde archivo CSV.
    
    Args:
        path (str): Ruta al archivo de cache
    
    Returns:
        Dict[Tuple[float, float], float]: Diccionario con (lat, lon) -> altitud
    """
    cache = {}
    
    if not os.path.exists(path):
        print(f"🗂️  No se encontro cache de altitudes. Iniciando nuevo.")
        return cache
    
    try:
        df_cache = pd.read_csv(path)
        for _, row in df_cache.iterrows():
            key = (round(row['latitude'], COORD_PRECISION), round(row['longitude'], COORD_PRECISION))
            cache[key] = row['elevation']
        
        print(f"🗂️  Cargado cache de altitudes con {len(cache)} entradas")
    except Exception as e:
        print(f"⚠️  Error cargando cache de altitudes: {e}")
        print(f"🗂️  Iniciando con cache vacio")
    
    return cache


def save_altitude_cache(cache: Dict[Tuple[float, float], float], path: str = "altitudes_cache.csv") -> None:
    """
    Guarda cache de altitudes a archivo CSV.
    
    Args:
        cache (Dict[Tuple[float, float], float]): Diccionario de cache a guardar
        path (str): Ruta donde guardar el archivo de cache
    """
    try:
        cache_data = []
        for (lat, lon), elevation in cache.items():
            cache_data.append({
                'latitude': lat,
                'longitude': lon,
                'elevation': elevation
            })
        
        df_cache = pd.DataFrame(cache_data)
        df_cache.to_csv(path, index=False, encoding='utf-8')
        print(f"💾 Guardado cache de altitudes con {len(cache)} entradas")
        
    except Exception as e:
        print(f"⚠️  Error guardando cache de altitudes: {e}")


def get_altitude(lat: float, lon: float, cache: Dict[Tuple[float, float], float]) -> float | None:
    """
    Obtiene altitud para coordenadas usando API Open-Elevation con cache.
    
    Args:
        lat (float): Latitud
        lon (float): Longitud
        cache (Dict[Tuple[float, float], float]): Cache de altitudes
    
    Returns:
        float | None: Altitud en metros sobre el nivel del mar, o None si falla
    """
    # Redondear coordenadas para cache
    lat_rounded = round(lat, COORD_PRECISION)
    lon_rounded = round(lon, COORD_PRECISION)
    cache_key = (lat_rounded, lon_rounded)
    
    # Verificar cache primero
    if cache_key in cache:
        return cache[cache_key]
    
    try:
        # Llamar API Open-Elevation
        params = {"locations": f"{lat},{lon}"}
        response = requests.get(OPEN_ELEVATION_URL, params=params, timeout=30)
        
        if response.status_code != 200:
            print(f"⚠️  Error API elevacion para ({lat}, {lon}): HTTP {response.status_code}")
            return None
        
        data = response.json()
        
        if not data.get("results") or len(data["results"]) == 0:
            print(f"⚠️  Sin datos de elevacion para ({lat}, {lon})")
            return None
        
        elevation = data["results"][0]["elevation"]
        
        # Guardar en cache
        cache[cache_key] = elevation
        
        # Pausa para no saturar la API
        time.sleep(0.1)
        
        return elevation
        
    except requests.RequestException as e:
        print(f"⚠️  Error de red obteniendo elevacion para ({lat}, {lon}): {e}")
        return None
    except Exception as e:
        print(f"⚠️  Error procesando elevacion para ({lat}, {lon}): {e}")
        return None


def calculate_annual_average(monthly_data: Dict[str, float]) -> float | None:
    """
    Calcula promedio anual desde datos mensuales de NASA POWER.
    
    Args:
        monthly_data (Dict[str, float]): Datos mensuales (claves: "JAN", "FEB", etc.)
    
    Returns:
        float | None: Promedio anual o None si datos insuficientes
    """
    if not monthly_data:
        return None
    
    # Intentar con abreviaciones de meses (formato NASA POWER)
    month_abbrevs = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", 
                     "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]
    
    values = []
    for month in month_abbrevs:
        if month in monthly_data and monthly_data[month] is not None:
            values.append(monthly_data[month])
    
    # Si no hay abreviaciones, intentar formato numerico
    if not values:
        for month in ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]:
            if month in monthly_data and monthly_data[month] is not None:
                values.append(monthly_data[month])
    
    if len(values) < 6:  # Requerir al menos 6 meses de datos
        return None
    
    return sum(values) / len(values)


def fetch_power_climatology(lat: float, lon: float) -> Dict[str, float | None]:
    """
    Obtiene datos climatologicos de NASA POWER para analisis de energias renovables.
    
    Args:
        lat (float): Latitud
        lon (float): Longitud
    
    Returns:
        Dict[str, float | None]: Diccionario con parametros de energias renovables
    """
    result = {
        "radiacion_kWhm2_dia": None,
        "viento_ms": None,
        "temperatura_C": None,
        "humedad_relativa_pct": None,
        "nubosidad_pct": None,
    }
    
    try:
        # Preparar parametros de API
        params = {
            "latitude": lat,
            "longitude": lon,
            "community": "RE",  # Renewable Energy community
            "parameters": ",".join(POWER_PARAMS),
            "format": "JSON"
        }
        
        print(f"🌍 Obteniendo datos NASA POWER para ({lat:.4f}, {lon:.4f})...")
        
        # Hacer peticion API
        response = requests.get(POWER_BASE_URL, params=params, timeout=60)
        
        if response.status_code != 200:
            print(f"⚠️  Error API NASA POWER para ({lat}, {lon}): HTTP {response.status_code}")
            return result
        
        data = response.json()
        
        # Extraer datos de parametros
        if "properties" not in data or "parameter" not in data["properties"]:
            print(f"⚠️  Formato de respuesta NASA POWER invalido para ({lat}, {lon})")
            return result
        
        parameters = data["properties"]["parameter"]
        
        # Calcular promedios anuales
        ghi_all = calculate_annual_average(parameters.get("ALLSKY_SFC_SW_DWN", {}))
        wind_speed = calculate_annual_average(parameters.get("WS10M", {}))
        temperature = calculate_annual_average(parameters.get("T2M", {}))
        humidity = calculate_annual_average(parameters.get("RH2M", {}))
        ghi_clear = calculate_annual_average(parameters.get("CLRSKY_SFC_SW_DWN", {}))
        
        # Calcular nubosidad
        cloudiness = None
        if ghi_all is not None and ghi_clear is not None and ghi_clear > 0:
            cloudiness = max(0, min(100, (1 - ghi_all / ghi_clear) * 100))
        
        # Actualizar resultado
        result.update({
            "radiacion_kWhm2_dia": ghi_all,
            "viento_ms": wind_speed,
            "temperatura_C": temperature,
            "humedad_relativa_pct": humidity,
            "nubosidad_pct": cloudiness,
        })
        
        # Pausa para no saturar la API
        time.sleep(0.3)
        
        return result
        
    except requests.RequestException as e:
        print(f"⚠️  Error de red obteniendo datos NASA POWER para ({lat}, {lon}): {e}")
        return result
    except Exception as e:
        print(f"⚠️  Error procesando datos NASA POWER para ({lat}, {lon}): {e}")
        return result


def load_zni_data() -> pd.DataFrame:
    """
    Carga datos de Zonas No Interconectadas desde datos.gov.co
    
    Returns:
        pd.DataFrame: DataFrame con datos de municipios/localidades ZNI
    """
    print(f"🏢 Cargando datos ZNI desde datos.gov.co...")
    
    try:
        # Preparar headers
        headers = {
            "User-Agent": "Dataset-Potencial-Renovable/1.0",
            "Accept": "application/json"
        }
        if APP_TOKEN_ZNI:
            headers["X-App-Token"] = APP_TOKEN_ZNI
            print(f"🔑 Usando token de aplicacion para API ZNI")
        
        all_records = []
        offset = 0
        limit = 1000
        
        while True:
            params = {
                "$limit": limit,
                "$offset": offset
            }
            
            response = requests.get(ZNI_URL, params=params, headers=headers, timeout=30)
            
            if response.status_code != 200:
                print(f"⚠️  Error API ZNI: HTTP {response.status_code}")
                break
            
            data = response.json()
            
            if not data:  # No mas registros
                break
            
            all_records.extend(data)
            
            if len(data) < limit:  # Ultima pagina
                break
            
            offset += limit
            print(f"📥 Descargados {len(all_records)} registros ZNI...")
        
        if not all_records:
            print(f"⚠️  No se obtuvieron datos ZNI")
            return pd.DataFrame()
        
        df_zni = pd.DataFrame(all_records)
        print(f"✅ Cargados {len(df_zni)} registros ZNI")
        
        return df_zni
        
    except Exception as e:
        print(f"❌ Error cargando datos ZNI: {e}")
        return pd.DataFrame()


def normalize_text(text: str) -> str:
    """Normaliza texto para comparacion consistente."""
    if pd.isna(text):
        return ""
    
    # Normalizar y eliminar acentos basicos
    result = str(text).upper().strip()
    
    # Eliminar acentos comunes
    replacements = {
        'Á': 'A', 'É': 'E', 'Í': 'I', 'Ó': 'O', 'Ú': 'U', 'Ñ': 'N', 'Ü': 'U'
    }
    for old, new in replacements.items():
        result = result.replace(old, new)
    
    return result


def compute_tipo_red(df_div: pd.DataFrame, df_zni: pd.DataFrame) -> pd.Series:
    """
    Calcula tipo de red (SIN/ZNI) para cada municipio basado en dataset ZNI.
    
    Args:
        df_div (pd.DataFrame): DataFrame de municipios DIVIPOLA
        df_zni (pd.DataFrame): DataFrame de datos ZNI
    
    Returns:
        pd.Series: Serie con tipo de red para cada municipio
    """
    if df_zni.empty:
        print(f"⚠️  Sin datos ZNI. Todos los municipios seran marcados como SIN")
        return pd.Series(["SIN"] * len(df_div))
    
    # Identificar columnas relevantes en dataset ZNI
    dept_cols = [col for col in df_zni.columns if 'depart' in col.lower() or 'dpto' in col.lower()]
    mun_cols = [col for col in df_zni.columns if any(x in col.lower() for x in ['munic', 'mpio', 'localid', 'poblad'])]
    
    print(f"🔍 Columnas departamento ZNI encontradas: {dept_cols}")
    print(f"🔍 Columnas municipio/localidad ZNI encontradas: {mun_cols}")
    
    # Extraer y normalizar nombres de lugares ZNI
    zni_places = set()
    
    for col in mun_cols:
        if col in df_zni.columns:
            places = df_zni[col].dropna().astype(str)
            normalized_places = places.apply(normalize_text)
            zni_places.update(normalized_places.tolist())
    
    # Tambien incluir departamentos (algunos pueden ser completamente ZNI)
    for col in dept_cols:
        if col in df_zni.columns:
            depts = df_zni[col].dropna().astype(str)
            normalized_depts = depts.apply(normalize_text)
            zni_places.update(normalized_depts.tolist())
    
    print(f"🏢 Encontrados {len(zni_places)} lugares/departamentos ZNI unicos")
    
    # Clasificar cada municipio
    def classify_municipality(row):
        mun_normalized = normalize_text(row['municipio'])
        dept_normalized = normalize_text(row['departamento'])
        
        if mun_normalized in zni_places or dept_normalized in zni_places:
            return "ZNI"
        else:
            return "SIN"
    
    return df_div.apply(classify_municipality, axis=1)


def build_dataset() -> pd.DataFrame:
    """
    Construye el dataset completo de potencial de energias renovables.
    
    Returns:
        pd.DataFrame: Dataset completo con todos los parametros de energias renovables
    """
    print("🏗️  Construyendo dataset de potencial de energias renovables...")
    print("=" * 70)
    
    # Paso 1: Cargar datos base DIVIPOLA
    df_base = load_divipola()
    total_municipalities = len(df_base)
    
    # Paso 2: Cargar cache de altitudes
    altitude_cache = load_altitude_cache()
    
    # Paso 3: Cargar datos ZNI
    df_zni = load_zni_data()
    
    # Paso 4: Procesar cada municipio
    results = []
    
    print(f"🔄 Procesando {total_municipalities} municipios...")
    
    for idx, row in df_base.iterrows():
        print(f"🏘️  [{idx+1}/{total_municipalities}] {row['departamento']} - {row['municipio']}")
        
        lat = row['latitud']
        lon = row['longitud']
        
        # Obtener altitud
        altitude = get_altitude(lat, lon, altitude_cache)
        
        # Obtener datos climatologicos NASA POWER
        power_data = fetch_power_climatology(lat, lon)
        
        # Construir registro resultado
        result = {
            'departamento': row['departamento'],
            'municipio': row['municipio'],
            'codigo_dane_municipio': row['codigo_dane_municipio'],
            'latitud': lat,
            'longitud': lon,
            'altitud_msnm': altitude,
            'radiacion_kWhm2_dia': power_data['radiacion_kWhm2_dia'],
            'viento_ms': power_data['viento_ms'],
            'temperatura_C': power_data['temperatura_C'],
            'humedad_relativa_pct': power_data['humedad_relativa_pct'],
            'nubosidad_pct': power_data['nubosidad_pct'],
            'demanda_kWh_mes': None,  # Para llenar despues
            'relieve_indice': None,   # Para llenar despues
            'potencial': None         # Para llenar despues
        }
        
        results.append(result)
    
    # Paso 5: Crear DataFrame desde resultados
    df_final = pd.DataFrame(results)
    
    # Paso 6: Calcular tipo de red (SIN/ZNI)
    print(f"🏢 Calculando clasificacion de tipo de red...")
    df_final['tipo_red'] = compute_tipo_red(df_final, df_zni)
    
    # Paso 7: Guardar cache de altitudes actualizado
    save_altitude_cache(altitude_cache)
    
    # Paso 8: Ordenamiento final de columnas
    final_columns = [
        'departamento', 'municipio', 'codigo_dane_municipio', 'latitud', 'longitud',
        'altitud_msnm', 'radiacion_kWhm2_dia', 'viento_ms', 'temperatura_C',
        'humedad_relativa_pct', 'nubosidad_pct', 'tipo_red', 'demanda_kWh_mes',
        'relieve_indice', 'potencial'
    ]
    
    df_final = df_final[final_columns]
    
    print(f"✅ ¡Construccion del dataset completada!")
    return df_final


def main() -> None:
    """
    Punto de entrada principal para construccion del dataset de potencial renovable.
    """
    print("🇨🇴 Dataset Potencial Renovable - Constructor Completo")
    print("=" * 70)
    print(f"🎯 Objetivo: Dataset completo de potencial renovable por municipio")
    print(f"📊 Entrada: {DIVIPOLA_CSV}")
    print(f"🌍 APIs: NASA POWER, Open-Elevation, Datos.gov.co ZNI")
    print(f"📁 Salida: {OUTPUT_CSV}")
    print("=" * 70)
    
    try:
        # Construir el dataset completo
        df_final = build_dataset()
        
        # Mostrar estadisticas
        print("\n📈 ESTADISTICAS DEL DATASET FINAL")
        print("=" * 50)
        print(f"✅ Total municipios procesados: {len(df_final)}")
        print(f"🗺️  Departamentos unicos: {df_final['departamento'].nunique()}")
        
        # Estadisticas tipo de red
        tipo_red_counts = df_final['tipo_red'].value_counts()
        print(f"🔌 Tipo de red:")
        for tipo, count in tipo_red_counts.items():
            pct = (count / len(df_final)) * 100
            print(f"   - {tipo}: {count} municipios ({pct:.1f}%)")
        
        # Completitud de datos
        print(f"\n📊 Completitud de datos:")
        data_columns = ['altitud_msnm', 'radiacion_kWhm2_dia', 'viento_ms', 'temperatura_C']
        for col in data_columns:
            non_null_count = df_final[col].notna().sum()
            pct = (non_null_count / len(df_final)) * 100
            print(f"   - {col}: {non_null_count}/{len(df_final)} ({pct:.1f}%)")
        
        # Vista previa de datos
        print(f"\n📋 Primeros 3 registros:")
        print(df_final.head(3).to_string(index=False, max_cols=8, float_format='%.2f'))
        
        # Exportar a CSV
        print(f"\n💾 Guardando dataset final...")
        df_final.to_csv(OUTPUT_CSV, index=False, encoding='utf-8')
        
        print(f"✅ Dataset guardado exitosamente: {OUTPUT_CSV}")
        print(f"   📍 Ubicacion: {os.path.abspath(OUTPUT_CSV)}")
        print(f"   📦 Tamaño: {os.path.getsize(OUTPUT_CSV):,} bytes")
        print(f"   📊 Dimensiones: {df_final.shape[0]} filas × {df_final.shape[1]} columnas")
        
        print("\n🎉 ¡CONSTRUCCION DEL DATASET COMPLETADA EXITOSAMENTE!")
        print("🔋 El dataset esta listo para analisis de potencial renovable")
        
    except FileNotFoundError as e:
        print(f"❌ Archivo no encontrado: {e}")
        print(f"💡 Asegurate de que {DIVIPOLA_CSV} existe en la carpeta actual")
        return
    except requests.RequestException as e:
        print(f"❌ Error de red: {e}")
        print(f"💡 Verifica tu conexion a internet y reintenta")
        return
    except Exception as e:
        print(f"❌ Error inesperado: {e}")
        return


if __name__ == "__main__":
    main()