"""
Calculador de Potencial Energético Renovable para Colombia
=========================================================

Este script clasifica el potencial de energías renovables de cada municipio
basándose en parámetros técnicos reales de radiación solar, velocidad del viento
y condiciones climáticas, usando criterios establecidos por UPME e IEC.

Clasificaciones posibles:
- "solar": Alto potencial fotovoltaico
- "eolica": Alto potencial eólico  
- "hibrida": Potencial combinado solar-eólico
- "desconocido": Datos insuficientes para clasificar

Author: Generated for renewable energy potential analysis
Date: November 2025
"""

import pandas as pd
import numpy as np


# =============================================================================
# CONFIGURACIÓN Y CONSTANTES
# =============================================================================

# Archivos de entrada y salida
INPUT_CSV = "dataset_potencial_renovable.csv"
OUTPUT_CSV = "dataset_potencial_renovable_potencial.csv"

# PARÁMETROS TÉCNICOS PARA CLASIFICACIÓN SOLAR
# Basados en:
# - UPME Atlas de Radiación Solar de Colombia
# - NASA POWER Global Horizontal Irradiance thresholds
# - Rango típico colombiano: 3.5 – 6.5 kWh/m²/día
# - Estudios técnicos de viabilidad fotovoltaica en el trópico

SOLAR_RADIACION_ALTA = 4.5      # kWh/m²/día - Umbral para potencial solar alto
SOLAR_RADIACION_MEDIA = 4.0     # kWh/m²/día - Umbral para potencial solar medio
SOLAR_NUBOSIDAD_MAX = 40        # % - Máxima nubosidad aceptable para solar puro

# PARÁMETROS TÉCNICOS PARA CLASIFICACIÓN EÓLICA  
# Basados en:
# - IEC 61400 (International Electrotechnical Commission) - Clases de aerogeneradores
# - UPME Atlas de Viento y Energía Eólica de Colombia
# - Ventanas de operación típicas para turbinas comerciales:
#   * Clase I: >8.5 m/s (sitios de viento alto)
#   * Clase II: 7.5-8.5 m/s (sitios de viento medio-alto)  
#   * Clase III: 6.0-7.5 m/s (sitios de viento medio)
# - Velocidad de arranque típica: 3-4 m/s
# - Velocidad nominal: 12-15 m/s

EOLICA_VIENTO_ALTO = 6.0        # m/s - Excelente para Clase II-III
EOLICA_VIENTO_MEDIO = 5.0       # m/s - Bueno para Clase III
EOLICA_VIENTO_BAJO_MEDIO = 4.0  # m/s - Aceptable para Clase III pequeña
EOLICA_VIENTO_MINIMO = 4.0      # m/s - Mínimo viable para generación


# =============================================================================
# FUNCIÓN PRINCIPAL DE CLASIFICACIÓN
# =============================================================================

def clasificar_potencial(radiacion_kWhm2_dia, viento_ms, nubosidad_pct):
    """
    Clasifica el potencial de energías renovables de un municipio basándose
    en criterios técnicos establecidos por organismos internacionales.
    
    Parámetros de entrada:
    - radiacion_kWhm2_dia (float): Irradiación solar global horizontal promedio anual
    - viento_ms (float): Velocidad promedio del viento a 10m de altura  
    - nubosidad_pct (float): Porcentaje de nubosidad promedio anual
    
    Criterios de clasificación técnica:
    
    🔆 SOLAR: Municipios óptimos para energía fotovoltaica
    - Requiere alta irradiación (≥4.5 kWh/m²/día) según estándares UPME
    - Viento bajo (<4.0 m/s) para evitar conflicto con eólica
    - Baja nubosidad (≤40%) para maximizar radiación directa
    
    🌬️ EÓLICA: Municipios óptimos para energía eólica
    - Viento alto (≥6.0 m/s) según IEC 61400 Clase II
    - O viento medio (5.0-6.0 m/s) con radiación insuficiente para solar
    - Prioriza el recurso eólico cuando es abundante
    
    ⚡ HÍBRIDA: Municipios óptimos para sistemas combinados
    - Ambos recursos en niveles aprovechables simultáneamente
    - Permite complementariedad estacional y diaria
    - Maximiza factor de planta del sistema energético
    
    Returns:
        str: Clasificación del potencial ("solar", "eolica", "hibrida", "desconocido")
    """
    
    # VALIDACIÓN DE DATOS: Verificar que no hay valores faltantes
    # Si algún parámetro crítico es NaN, no se puede hacer clasificación confiable
    if pd.isna(radiacion_kWhm2_dia) or pd.isna(viento_ms) or pd.isna(nubosidad_pct):
        return "desconocido"
    
    # CLASIFICACIÓN SOLAR
    # Un municipio tiene potencial solar dominante cuando:
    # 1. La irradiación es alta (≥4.5 kWh/m²/día) - suficiente para plantas FV comerciales
    # 2. El viento es bajo (<4.0 m/s) - no compite con eólica, evita conflicto de uso
    # 3. La nubosidad es baja (≤40%) - garantiza radiación directa consistente
    if radiacion_kWhm2_dia >= SOLAR_RADIACION_ALTA and viento_ms < EOLICA_VIENTO_MINIMO and nubosidad_pct <= SOLAR_NUBOSIDAD_MAX:
        return "solar"
    
    # CLASIFICACIÓN EÓLICA - CASO 1: Viento excelente
    # Viento alto (≥6.0 m/s) es excelente para aerogeneradores Clase II
    # En este caso, el potencial eólico domina independientemente de la radiación
    if viento_ms >= EOLICA_VIENTO_ALTO:
        return "eolica"
    
    # CLASIFICACIÓN EÓLICA - CASO 2: Viento medio con radiación insuficiente  
    # Viento medio (5.0-6.0 m/s) es viable para Clase III cuando la radiación no es suficiente
    # Evita competencia de recursos y maximiza el recurso disponible
    if EOLICA_VIENTO_MEDIO <= viento_ms < EOLICA_VIENTO_ALTO and radiacion_kWhm2_dia < SOLAR_RADIACION_ALTA:
        return "eolica"
    
    # CLASIFICACIÓN HÍBRIDA - CASO 1: Radiación alta + viento aprovechable
    # Ambos recursos son buenos, permite sistemas complementarios
    # La radiación alta justifica FV, el viento aprovechable permite complemento eólico
    if radiacion_kWhm2_dia >= SOLAR_RADIACION_ALTA and viento_ms >= EOLICA_VIENTO_BAJO_MEDIO:
        return "hibrida"
    
    # CLASIFICACIÓN HÍBRIDA - CASO 2: Radiación media + viento alto
    # El viento alto compensa la radiación media, sistema híbrido balanceado
    if SOLAR_RADIACION_MEDIA <= radiacion_kWhm2_dia < SOLAR_RADIACION_ALTA and viento_ms >= EOLICA_VIENTO_MEDIO:
        return "hibrida"
    
    # CLASIFICACIÓN HÍBRIDA - CASO 3: Ambos recursos en nivel medio
    # Ningún recurso domina claramente, la hibridación optimiza el aprovechamiento
    if SOLAR_RADIACION_MEDIA <= radiacion_kWhm2_dia < SOLAR_RADIACION_ALTA and EOLICA_VIENTO_BAJO_MEDIO <= viento_ms < EOLICA_VIENTO_MEDIO:
        return "hibrida"
    
    # CASO NO CLASIFICABLE
    # Los recursos están por debajo de los umbrales técnicos mínimos
    # O no cumplen ninguna de las combinaciones viables establecidas
    return "desconocido"


# =============================================================================
# FUNCIÓN DE PROCESAMIENTO PRINCIPAL
# =============================================================================

def procesar_dataset():
    """
    Procesa el dataset completo aplicando la clasificación de potencial
    a todos los municipios y generando estadísticas del resultado.
    """
    
    print("🔋 Calculador de Potencial Energético Renovable")
    print("=" * 55)
    print(f"📊 Procesando: {INPUT_CSV}")
    print(f"💾 Salida: {OUTPUT_CSV}")
    print("=" * 55)
    
    try:
        # CARGA DEL DATASET
        print("\n📂 Cargando dataset de potencial renovable...")
        df = pd.read_csv(INPUT_CSV, encoding='utf-8')
        print(f"✅ Dataset cargado: {len(df)} municipios")
        
        # VALIDACIÓN DE COLUMNAS REQUERIDAS
        columnas_requeridas = ['radiacion_kWhm2_dia', 'viento_ms', 'nubosidad_pct']
        columnas_faltantes = [col for col in columnas_requeridas if col not in df.columns]
        
        if columnas_faltantes:
            raise ValueError(f"Faltan columnas requeridas en el dataset: {columnas_faltantes}")
        
        print(f"📋 Columnas de análisis encontradas: {columnas_requeridas}")
        
        # APLICACIÓN DE LA CLASIFICACIÓN
        print("\n🧮 Aplicando clasificación de potencial energético...")
        print("   📏 Criterios técnicos:")
        print(f"   🔆 Solar: Radiación ≥{SOLAR_RADIACION_ALTA} kWh/m²/día, Viento <{EOLICA_VIENTO_MINIMO} m/s, Nubosidad ≤{SOLAR_NUBOSIDAD_MAX}%")
        print(f"   🌬️ Eólica: Viento ≥{EOLICA_VIENTO_ALTO} m/s, o Viento ≥{EOLICA_VIENTO_MEDIO} m/s con Radiación <{SOLAR_RADIACION_ALTA}")
        print(f"   ⚡ Híbrida: Combinaciones aprovechables de ambos recursos")
        
        # Aplicar la función de clasificación a cada fila del dataset
        df['potencial'] = df.apply(
            lambda row: clasificar_potencial(
                row['radiacion_kWhm2_dia'], 
                row['viento_ms'], 
                row['nubosidad_pct']
            ), 
            axis=1
        )
        
        print("✅ Clasificación completada")
        
        # GENERACIÓN DE ESTADÍSTICAS
        print("\n📈 ESTADÍSTICAS DE CLASIFICACIÓN")
        print("=" * 40)
        
        conteos = df['potencial'].value_counts()
        total = len(df)
        
        print(f"📊 Total municipios analizados: {total}")
        print("\n🔋 Distribución del potencial energético:")
        
        for categoria in ['solar', 'eolica', 'hibrida', 'desconocido']:
            count = conteos.get(categoria, 0)
            porcentaje = (count / total) * 100
            emoji = {'solar': '🔆', 'eolica': '🌬️', 'hibrida': '⚡', 'desconocido': '❓'}[categoria]
            print(f"   {emoji} {categoria.upper():<10}: {count:4d} municipios ({porcentaje:5.1f}%)")
        
        # ANÁLISIS POR DEPARTAMENTOS (TOP 5)
        print(f"\n🗺️  Top 5 departamentos por potencial solar:")
        solar_por_dept = df[df['potencial'] == 'solar']['departamento'].value_counts().head()
        for dept, count in solar_por_dept.items():
            print(f"   🔆 {dept}: {count} municipios")
        
        print(f"\n💨 Top 5 departamentos por potencial eólico:")
        eolico_por_dept = df[df['potencial'] == 'eolica']['departamento'].value_counts().head()
        for dept, count in eolico_por_dept.items():
            print(f"   🌬️ {dept}: {count} municipios")
        
        print(f"\n⚡ Top 5 departamentos por potencial híbrido:")
        hibrido_por_dept = df[df['potencial'] == 'hibrida']['departamento'].value_counts().head()
        for dept, count in hibrido_por_dept.items():
            print(f"   ⚡ {dept}: {count} municipios")
        
        # GUARDAR DATASET ACTUALIZADO
        print(f"\n💾 Guardando dataset con clasificación de potencial...")
        df.to_csv(OUTPUT_CSV, index=False, encoding='utf-8')
        
        print(f"✅ Dataset guardado exitosamente: {OUTPUT_CSV}")
        print(f"   📍 Ubicación: {INPUT_CSV.replace(INPUT_CSV.split('/')[-1], '')}") 
        print(f"   📊 Dimensiones: {df.shape[0]} municipios × {df.shape[1]} columnas")
        print(f"   🔋 Nueva columna: 'potencial' con clasificación energética")
        
        # RESUMEN DE CALIDAD DE DATOS
        datos_completos = df[df['potencial'] != 'desconocido'].shape[0]
        porcentaje_completo = (datos_completos / total) * 100
        
        print(f"\n📊 CALIDAD DEL ANÁLISIS:")
        print(f"   ✅ Municipios con clasificación: {datos_completos}/{total} ({porcentaje_completo:.1f}%)")
        print(f"   ❓ Municipios con datos insuficientes: {total-datos_completos}/{total} ({100-porcentaje_completo:.1f}%)")
        
        print("\n🎉 ¡CLASIFICACIÓN DE POTENCIAL ENERGÉTICO COMPLETADA!")
        print("🔋 El dataset está listo para análisis de viabilidad de proyectos renovables")
        
    except FileNotFoundError:
        print(f"❌ Error: No se encontró el archivo {INPUT_CSV}")
        print("💡 Asegúrate de que el archivo existe en la carpeta actual")
        return
    
    except pd.errors.EmptyDataError:
        print(f"❌ Error: El archivo {INPUT_CSV} está vacío")
        return
    
    except ValueError as e:
        print(f"❌ Error en los datos: {e}")
        return
    
    except Exception as e:
        print(f"❌ Error inesperado: {e}")
        return


# =============================================================================
# EJECUCIÓN PRINCIPAL
# =============================================================================

if __name__ == "__main__":
    procesar_dataset()


# =============================================================================
# DOCUMENTACIÓN TÉCNICA ADICIONAL
# =============================================================================

"""
CRITERIOS TÉCNICOS DETALLADOS PARA CLASIFICACIÓN

🔆 ENERGÍA SOLAR FOTOVOLTAICA:
- Radiación Global Horizontal (GHI) mínima: 4.5 kWh/m²/día
- Basado en estudios de viabilidad económica para Colombia (UPME, 2015)
- Factor de planta típico >15% para proyectos comerciales
- Nubosidad <40% para optimizar radiación directa normal (DNI)
- Evita competencia con eólica cuando viento <4 m/s

🌬️ ENERGÍA EÓLICA:
- Velocidad mínima viable: 4.0 m/s (según IEC 61400-1)
- Velocidad objetivo Clase III: 6.0 m/s (factor de planta >25%)  
- Velocidad objetivo Clase II: 7.5+ m/s (factor de planta >35%)
- Considera altura de 10m, extrapolable a altura de buje (80-100m)
- Prioriza recurso eólico cuando es abundante (≥6 m/s)

⚡ SISTEMAS HÍBRIDOS:
- Aprovecha complementariedad temporal de recursos
- Maximiza factor de planta combinado (>40%)
- Reduce intermitencia y mejora estabilidad de red
- Óptimo cuando ningún recurso domina completamente
- Considera almacenamiento energético implícito

📊 CASOS ESPECIALES:
- "desconocido": Datos faltantes o fuera de rangos técnicos
- No se interpolan ni estiman datos faltantes
- Mantiene integridad científica del análisis
- Permite identificar áreas que requieren medición adicional

🎯 APLICACIONES DEL ANÁLISIS:
- Planificación energética nacional y regional
- Identificación de zonas de desarrollo renovable
- Estudios de prefactibilidad para inversionistas  
- Complemento para análisis de red eléctrica (SIN/ZNI)
- Base para políticas públicas energéticas
"""