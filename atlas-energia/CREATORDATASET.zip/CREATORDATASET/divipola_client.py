"""
DIVIPOLA API Client - Colombia Open Data Platform
==================================================

This script connects to the DIVIPOLA (Division Político Administrativa) API
from Colombia's Open Data platform to download all municipalities data.

Dataset: DIVIPOLA – Códigos municipios
Dataset ID: gdxc-w37w
API Documentation: https://dev.socrata.com/foundry/www.datos.gov.co/gdxc-w37w

Author: Generated for data extraction and analysis
Date: November 2025
"""

import os
import requests
import pandas as pd
from typing import List, Dict, Any
import time


# =============================================================================
# CONFIGURATION
# =============================================================================

# SODA API v2 endpoint (main endpoint used in this script)
BASE_URL_V2 = "https://www.datos.gov.co/resource/gdxc-w37w.json"

# SODA API v3 endpoint (for future extensions requiring complex queries)
BASE_URL_V3 = "https://www.datos.gov.co/api/v3/views/gdxc-w37w/query.json"

# Default pagination limit (SODA v2 supports up to 1000 per request)
DEFAULT_LIMIT = 1000

# Output file name
OUTPUT_CSV = "DIVIPOLA_municipios.csv"

# App token for rate limiting (optional but recommended)
# Set environment variable: DATOS_GOV_APP_TOKEN=your_token_here
APP_TOKEN = os.getenv("DATOS_GOV_APP_TOKEN", None)

# Expected total records (for validation)
EXPECTED_TOTAL_RECORDS = 1122


# =============================================================================
# API CLIENT FUNCTIONS
# =============================================================================

def fetch_divipola_all_rows(limit: int = DEFAULT_LIMIT) -> List[Dict[str, Any]]:
    """
    Download all DIVIPOLA records using SODA v2 API with pagination.
    
    This function handles pagination automatically to ensure all records
    are retrieved without hitting API limits.
    
    Args:
        limit (int): Number of records to fetch per API call (max 1000)
    
    Returns:
        List[Dict[str, Any]]: Complete list of all municipality records
    
    Raises:
        requests.RequestException: If API request fails
        ValueError: If API returns unexpected data format
    """
    all_records = []
    offset = 0
    
    # Prepare headers with optional app token
    headers = {
        "User-Agent": "DIVIPOLA-Client/1.0",
        "Accept": "application/json"
    }
    if APP_TOKEN:
        headers["X-App-Token"] = APP_TOKEN
        print(f"🔑 Using app token for API requests")
    
    print(f"📡 Starting download from DIVIPOLA API...")
    print(f"🔗 Endpoint: {BASE_URL_V2}")
    
    while True:
        # Prepare query parameters
        params = {
            "$limit": limit,
            "$offset": offset,
            "$order": "cod_mpio"  # Ensure consistent ordering
        }
        
        try:
            print(f"📥 Fetching records {offset + 1} to {offset + limit}...")
            
            # Make API request
            response = requests.get(
                BASE_URL_V2, 
                params=params, 
                headers=headers,
                timeout=30
            )
            
            # Check for HTTP errors
            if response.status_code != 200:
                error_msg = f"API request failed with status {response.status_code}"
                try:
                    error_detail = response.json()
                    error_msg += f": {error_detail}"
                except:
                    error_msg += f": {response.text[:200]}"
                raise requests.RequestException(error_msg)
            
            # Parse JSON response
            data = response.json()
            
            # Handle different response formats
            if isinstance(data, dict) and "value" in data:
                # Response wrapped in {"value": [...], "Count": N}
                records = data["value"]
                print(f"✅ Retrieved {len(records)} records (total so far: {len(all_records) + len(records)})")
            elif isinstance(data, list):
                # Direct list response
                records = data
                print(f"✅ Retrieved {len(records)} records (total so far: {len(all_records) + len(records)})")
            else:
                raise ValueError(f"Unexpected API response format: {type(data)}")
            
            # Add records to total collection
            all_records.extend(records)
            
            # Check if we've reached the end (fewer records than requested)
            if len(records) < limit:
                print(f"🏁 Reached end of dataset. Total records downloaded: {len(all_records)}")
                break
            
            # Prepare for next page
            offset += limit
            
            # Small delay to be respectful to the API
            time.sleep(0.1)
            
        except requests.RequestException as e:
            raise requests.RequestException(f"Failed to fetch data from API: {str(e)}")
        except Exception as e:
            raise ValueError(f"Error processing API response: {str(e)}")
    
    # Validate total record count
    if len(all_records) < EXPECTED_TOTAL_RECORDS * 0.9:  # Allow 10% tolerance
        print(f"⚠️  Warning: Expected ~{EXPECTED_TOTAL_RECORDS} records, but got {len(all_records)}")
    
    print(f"✨ Successfully downloaded {len(all_records)} DIVIPOLA records")
    return all_records


def normalize_divipola_records(records: List[Dict[str, Any]]) -> pd.DataFrame:
    """
    Normalize and clean DIVIPOLA records into a standardized DataFrame.
    
    This function:
    1. Converts the records to a pandas DataFrame
    2. Selects and renames relevant columns
    3. Cleans and validates data types
    4. Handles coordinate conversion
    
    Args:
        records (List[Dict[str, Any]]): Raw records from API
    
    Returns:
        pd.DataFrame: Cleaned DataFrame with standardized columns
    
    Raises:
        ValueError: If required columns are missing or data is invalid
    """
    if not records:
        raise ValueError("No records provided for normalization")
    
    # Create DataFrame from records
    df = pd.DataFrame(records)
    
    print(f"📊 Processing {len(df)} records...")
    print(f"📋 Available columns: {df.columns.tolist()}")
    
    # Map API column names to standardized names
    # Based on the API response structure discovered:
    column_mapping = {
        'dpto': 'departamento',
        'nom_mpio': 'municipio', 
        'cod_mpio': 'codigo_dane_municipio',
        'latitud': 'latitud',
        'longitud': 'longitud'
    }
    
    # Verify all required columns exist
    missing_columns = []
    for api_col in column_mapping.keys():
        if api_col not in df.columns:
            missing_columns.append(api_col)
    
    if missing_columns:
        raise ValueError(f"Missing required columns in API response: {missing_columns}")
    
    # Select and rename columns
    df_clean = df[list(column_mapping.keys())].copy()
    df_clean.columns = list(column_mapping.values())
    
    # Clean and standardize text fields
    df_clean['departamento'] = df_clean['departamento'].astype(str).str.strip().str.upper()
    df_clean['municipio'] = df_clean['municipio'].astype(str).str.strip().str.upper()
    df_clean['codigo_dane_municipio'] = df_clean['codigo_dane_municipio'].astype(str).str.strip()
    
    # Convert coordinates to float (handle comma decimal separator)
    def convert_coordinate(coord_str):
        """Convert coordinate string to float, handling comma decimal separator."""
        if pd.isna(coord_str):
            return None
        try:
            # Replace comma with dot for proper float conversion
            coord_clean = str(coord_str).replace(',', '.')
            return float(coord_clean)
        except (ValueError, TypeError):
            return None
    
    df_clean['latitud'] = df_clean['latitud'].apply(convert_coordinate)
    df_clean['longitud'] = df_clean['longitud'].apply(convert_coordinate)
    
    # Validate coordinates
    null_coords = df_clean[df_clean['latitud'].isna() | df_clean['longitud'].isna()]
    if len(null_coords) > 0:
        print(f"⚠️  Warning: Found {len(null_coords)} records with missing coordinates:")
        print(null_coords[['departamento', 'municipio', 'codigo_dane_municipio']].to_string(index=False))
    
    # Validate coordinate ranges for Colombia
    invalid_lat = df_clean[
        (df_clean['latitud'].notna()) & 
        ((df_clean['latitud'] < -4.5) | (df_clean['latitud'] > 16))
    ]
    invalid_lon = df_clean[
        (df_clean['longitud'].notna()) & 
        ((df_clean['longitud'] < -82) | (df_clean['longitud'] > -66))
    ]
    
    if len(invalid_lat) > 0:
        print(f"⚠️  Warning: Found {len(invalid_lat)} records with invalid latitude")
    if len(invalid_lon) > 0:
        print(f"⚠️  Warning: Found {len(invalid_lon)} records with invalid longitude")
    
    # Final column order
    final_columns = ['departamento', 'municipio', 'codigo_dane_municipio', 'latitud', 'longitud']
    df_final = df_clean[final_columns].copy()
    
    print(f"✅ Data normalization complete:")
    print(f"   - Records processed: {len(df_final)}")
    print(f"   - Columns: {df_final.columns.tolist()}")
    print(f"   - Data types: {df_final.dtypes.to_dict()}")
    
    return df_final


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main() -> None:
    """
    Main entry point for the DIVIPOLA data extraction process.
    
    This function orchestrates the complete workflow:
    1. Downloads all municipality records from the API
    2. Normalizes and cleans the data
    3. Exports to CSV file
    4. Provides summary statistics
    """
    print("🇨🇴 DIVIPOLA API Client - Colombia Municipalities Data")
    print("=" * 60)
    
    try:
        # Step 1: Download all records from API
        print("\n📡 Step 1: Downloading data from API...")
        records = fetch_divipola_all_rows()
        
        if not records:
            print("❌ No data retrieved from API. Exiting.")
            return
        
        print(f"✅ Successfully downloaded {len(records)} records")
        
        # Step 2: Normalize and clean data
        print("\n🧹 Step 2: Normalizing and cleaning data...")
        df = normalize_divipola_records(records)
        
        print(f"✅ Data cleaning complete. Final dataset shape: {df.shape}")
        
        # Step 3: Display sample data
        print("\n📊 Step 3: Data preview")
        print("First 5 records:")
        print(df.head().to_string(index=False))
        
        print(f"\nData summary:")
        print(f"  - Total municipalities: {len(df)}")
        print(f"  - Unique departments: {df['departamento'].nunique()}")
        print(f"  - Records with coordinates: {df.dropna(subset=['latitud', 'longitud']).shape[0]}")
        
        # Step 4: Export to CSV
        print(f"\n💾 Step 4: Exporting to CSV...")
        df.to_csv(OUTPUT_CSV, index=False, encoding='utf-8')
        
        print(f"✅ File saved successfully: {OUTPUT_CSV}")
        print(f"   - Location: {os.path.abspath(OUTPUT_CSV)}")
        print(f"   - Size: {os.path.getsize(OUTPUT_CSV)} bytes")
        
        print("\n🎉 DIVIPOLA data extraction completed successfully!")
        
    except requests.RequestException as e:
        print(f"❌ Network error: {e}")
        return
    except ValueError as e:
        print(f"❌ Data processing error: {e}")
        return
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return


if __name__ == "__main__":
    main()


# =============================================================================
# USAGE INSTRUCTIONS
# =============================================================================

"""
📖 HOW TO USE THIS SCRIPT
========================

1. INSTALL DEPENDENCIES:
   pip install requests pandas

2. OPTIONAL - SET APP TOKEN (recommended for better rate limits):
   Set environment variable in PowerShell:
   $env:DATOS_GOV_APP_TOKEN="your_app_token_here"
   
   Or in Command Prompt:
   set DATOS_GOV_APP_TOKEN=your_app_token_here

3. RUN THE SCRIPT:
   python divipola_client.py

4. OUTPUT:
   - The script will create 'DIVIPOLA_municipios.csv' in the same directory
   - The CSV contains all Colombian municipalities with their coordinates
   - Columns: departamento, municipio, codigo_dane_municipio, latitud, longitud

5. DATA USAGE:
   The generated CSV is ready to use for:
   - Geographic analysis and mapping
   - Cross-referencing with other Colombian datasets
   - Integration with weather APIs (e.g., NASA POWER)
   - Municipal-level data analysis

6. TROUBLESHOOTING:
   - If you get rate limit errors, consider getting an app token
   - For network timeouts, the script will retry automatically
   - Check your internet connection if downloads fail consistently

7. API INFORMATION:
   - Dataset: DIVIPOLA – Códigos municipios
   - Source: datos.gov.co (Colombia Open Data)
   - Documentation: https://dev.socrata.com/foundry/www.datos.gov.co/gdxc-w37w
   - License: Open data (verify current license terms)

8. EXTENSIONS:
   To modify for other queries, you can:
   - Use the BASE_URL_V3 endpoint for complex filtering
   - Add WHERE clauses using SODA query parameters
   - Modify column selection in normalize_divipola_records()
"""